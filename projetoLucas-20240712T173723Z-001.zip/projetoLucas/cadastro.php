<?php

$servername = "127.0.0.1";
$username =  "root";
$password = "";
$dbname = "golden_mob_shoes";

$conn = new mysqli($servername,$username,$password,$dbname);

if ($conn->connect_error){
    die("conexão  falhou".$conn->connect_error);
}

if($_SERVER["REQUEST_METHOD"] === "POST"){
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $senha = $_POST["senha"];


    $sql = "INSERT INTO  usuarios (nome, email,senha) VALUES ('$nome', '$email', '$senha')";
    

    if ($conn->query($sql) === TRUE){
        echo "cadastro realizado com sucesso . realize o seu login";
    } else {
        echo "erro: ".$sql. "<br>" . $conn->error;

    }
  } 

  $conn->close();


?>