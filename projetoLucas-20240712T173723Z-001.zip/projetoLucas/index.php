<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-commerce DTEC 2024</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

    <!-- INÍCIO DO BANNER -->
    <div class="banner">

        <!-- INÍCIO DO CONTEÚDO-->
        <div class="container">

            <!-- INÍCIO NAVEGAÇÃO-->
            <div class="navbar">

                <div class="logo">
                    <img src="assets/img/3-removebg-preview.png" alt="" width="300px">
                </div>

                <!-- INÍCIO MENU NAVEGAÇÃO -->
                <nav>
                    <ul id="MenuItens">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="produtos.php">Produtos</a></li>
                        <li><a href="acessorios.php" title="">Acessorios</a></li>
                        <li><a href="contatos.php" title="">Contatos</a></li>
                        <li><a href="minha-conta.php" title="">Minha Conta</a></li>
                    
                    </ul>
                </nav>
                <!-- FIM   MENU NAVEGAÇÃO -->

                <a href="carrinho.php" title="">
                    <img src="assets/img/carrinho.png" alt="" width="120px" height="120px">
                    </a>

                <img src="assets/img/menu.png" alt="" class="menu-celular" onclick="menucelular()" >

            </div>
            <!-- FIM NAVEGAÇÃO-->

            <!-- INÍCIO TEXTO DO BANNER -->
            <div class="linha">



                <div class="col-2">
                    <img src="assets/img/WhatsApp_Image_2024-05-24_at_14.40.33_-_Copia-removebg-preview.png" alt=""  >
                </div>
                   
                <div class="col-2">
                    <h1>Faça do seu Tenis  <br>o principal do seu estilo ! </h1>
                    <p> <br> 
                    </p>
                    <br><a href="ver-produto.24L.php" class="btn"> Mais informações &#8594;</a>
                </div>

             </div> 
            <!-- FIM TEXTO DO BANNER-->

        </div>
        <!-- FIM DO CONTEÚDO-->

    </div>
    <!-- FIM DO BANNER -->

    <!-- INÍCIO CATEGORIAS EM DESTAQUE    -->
    <div class="categorias">

        <!-- INÍCIO CORPO CATEGORIAS EM DESTAQUE    -->

        <div class="corpo-categorias">

            <!-- INICIO LINHA CORPO CATEGORIAS-->

            <div class="linha">

                <div class="col-3">
                    <img src="assets/img/Sabrina_1-removebg-preview.png">
                </div>

                <div class="col-3">
                    <img src="assets/img/Kyre_irving-removebg-preview.png" alt="">
                </div>

                <div class="col-3">
                    <img src="assets/img/AeroDunk.webp" alt="">
                </div>

            </div>

            <!-- FIM LINHA CORPO CATEGORIAS-->

        </div>

        <!-- FIM CORPO CATEGORIAS EM DESTAQUE    -->

    </div>
    <!-- FIM CATEGORIAS EM DESTAQUE    -->

    <!-- INÍCIO PRODUTOS EM DESTAQUE-->
    <div class="corpo-categorias">
        <h2 class="titulo"> Produtos em Destaque</h2>

        <!-- INÍCIO LINHA CORPO PRODUTOS EM DESTAQUE-->

        <div class="linha">
            <!-- INÍCIO ITEM PRODUTO-->

            <div class="col-4">
                <a href="ver-produto.php" title="">
                <img src="assets/img/24K Magic Premium.jpeg" alt="">
                </a>
                
                <h4>Tenis 24K Premium</h4>
                <div class="classificacao">
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                </div>

                <p>R$ 997,90</p>

            </div>

            <!-- FIM ITEM PRODUTO-->

            <!-- INÍCIO ITEM PRODUTO-->

            <div class="col-4">
            <a href="ver-produto.Asthetic.php" title="">
                <img src="assets/img/Aesthetic-Plus-Azul.jpeg" alt="">
               </a>

                <h4>Tenis Aesthetic Plus</h4>
                <div class="classificacao">
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                </div>

                <p>R$ 701,80</p>


            </div>

            <!-- FIM ITEM PRODUTO-->

            <!-- INÍCIO ITEM PRODUTO-->

            <div class="col-4">
            <a href="ver-produto.AestheticPlusRoxo.php" title="">
                <img src="assets/img/Aesthetic Plus Roxo.jpeg" alt="">
               </a>

                <h4>Tenis Aesthetic Plus</h4>
                <div class="classificacao">
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                </div>

                <p>R$ 650,00</p>


            </div>

            <!-- FIM ITEM PRODUTO-->

            <!-- INÍCIO ITEM PRODUTO-->

            <div class="col-4">
            <a href="ver-produto.Under Armour jet 21.php" title="">
                <img src="assets/img/Under Armour jet 21.jpeg" alt="">
               </a>

                <h4>Tenis Under jet 21</h4>
                <div class="classificacao">
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                </div>

                <p>R$ 299,99</p>


            </div>

            <!-- FIM ITEM PRODUTO-->


        </div>
        <!-- FIM LINHA CORPO PRODUTOS EM DESTAQUE-->

        <h2 class="titulo"> Novos Produtos</h2>

        <!-- INÍCIO LINHA CORPO PRODUTOS EM DESTAQUE-->

        <div class="linha">
            <!-- INÍCIO ITEM PRODUTO-->

            <div class="col-4">
            <a href="ver-produto.NikeLaranja.php" title="">
                <img src="assets/img/NikeDunk laranja.jpeg" alt="">
                </a>

                <h4>NikeDunk laranja</h4>
                <div class="classificacao">
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                </div>

                <p>R$ 500,00</p>


            </div>

            <!-- FIM ITEM PRODUTO-->

            <!-- INÍCIO ITEM PRODUTO-->

            <div class="col-4">
            <a href="ver-produto.Tn.php" title="">
                <img src="assets/img/Tn (1).jpeg" alt="">
                
                </a>

                <h4>Tn cinza</h4>
                <div class="classificacao">
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                </div>

                <p>R$ 300,00</p>


            </div>

            <!-- FIM ITEM PRODUTO-->

            <!-- INÍCIO ITEM PRODUTO-->

            <div class="col-4">
            <a href="ver-produto.MBlamelo.php" title="">
                <img src="assets/img/Mb_01_Lamelo-removebg-preview (1).png" alt="">
                </a>

                <h4>Mb 01 Lameelo</h4>
                <div class="classificacao">
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                </div>

                <p>R$ 669,00</p>


            </div>

            <!-- FIM ITEM PRODUTO-->

            <!-- INÍCIO ITEM PRODUTO-->

            <div class="col-4">
            <a href="ver-produto.KD16.php" title="">
                <img src="assets/img/KD 16.jpeg" alt="">
               
                </a>

                <h4>Kd 16 rosa </h4>
                <div class="classificacao">
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                </div>

                <p>R$ 550,90</p>


            </div>

            <!-- FIM ITEM PRODUTO-->

            <!-- INÍCIO ITEM PRODUTO-->

            <div class="col-4">
            <a href="ver-produto.BapeStar.php" title="">
                <img src="assets/img/Bape sta white roxo.jpg" alt="">
               
                </a>

                <h4>bape star white e roxo</h4>
                <div class="classificacao">
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                </div>

                <p>R$ 597,90</p>


            </div>

            <!-- FIM ITEM PRODUTO-->

            <!-- INÍCIO ITEM PRODUTO-->

            <div class="col-4">
            <a href="ver-produto.AirJordanWhite.php" title="">
                <img src="assets/img/Air jordan white.webp" alt="">
            
                </a>

                <h4>Air jordan white</h4>
                <div class="classificacao">
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                </div>

                <p>R$  597,90</p>


            </div>

            <!-- FIM ITEM PRODUTO-->

            <!-- INÍCIO ITEM PRODUTO-->

            <div class="col-4">
            <a href="ver-produto.NikeKyrie.php" title=""> 
                <img src="assets/img/Nike Kyrie Li 2.webp" alt="">
              
                </a>
                
                <h4>Nike Kyrie Li 2</h4>
                <div class="classificacao">
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                </div>

                <p>R$ 700,00</p>


            </div>

            <!-- FIM ITEM PRODUTO-->

            <!-- INÍCIO ITEM PRODUTO-->

            <div class="col-4">
            <a href="ver-produto.kdTrey.php" title="">
                <img src="assets/img/Kd trey 5X.jpg" alt="">
                
                </a>

                <h4>Kd trey 5X</h4>
                <div class="classificacao">
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                </div>

                <p>R$ 597,90</p>


            </div>

            <!-- FIM ITEM PRODUTO-->

            <!-- INÍCIO ITEM PRODUTO-->

            <div class="col-4">
            <a href="ver-produto.renewelevate.php" title="">
                <img src="assets/img/Renew elevate.jpg" alt="">
                </a>
                <h4>Renew elevate branco</h4>
                <div class="classificacao">
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                    <ion-icon name="star"></ion-icon>
                </div>

                <p>R$ 699,00</p>


            </div>

            <!-- FIM ITEM PRODUTO-->


        </div>
        <!-- FIM LINHA CORPO PRODUTOS EM DESTAQUE-->


    </div>
    <!-- FIM PRODUTOS EM DESTAQUE-->

    <!-- INÍCIO SESSÃO OFERTAS -->

    <div class="ofertas">

        <div class="corpo-categorias">

            <div class="linha">

                <div class="col-2">

                    <img src="assets/img/moletom-brooklyn-removebg-preview.png" alt="" class="oferta-img">

                </div>

                <div class="col-2">
                    <p>Produto Exclusivo da Loja</p>
                    <h1>Moletom brooklyn </h1>
                    <small> </small>
                    <br><br><a href="ver-produto.MoletomBrooklyn.php" class="btn">Comprar Agora! &#8594;</a>
                </div>

            </div>

        </div>
    </div>

    <!-- FIM SESSÃO OFERTAS -->

    <!-- INÍCIO DEPOIMENTOS-->
    <div class="depoimentos">

        <div class="corpo-categorias">
            <div class="linha">

                <!-- INÍCIO ITEM DEPOIMENTO -->
                <div class="col-3">
                    <ion-icon name="ribbon" class="depoimento-icone"></ion-icon>
                    <p>orem Ipsum is simply dummy text of the printing and typesetting industry</p>
                    <div class="classificacao">
                        <ion-icon name="star"></ion-icon>
                        <ion-icon name="star"></ion-icon>
                        <ion-icon name="star"></ion-icon>
                        <ion-icon name="star"></ion-icon>
                        <ion-icon name="star"></ion-icon>
                    </div>
                    <img src="assets/img/cliente-1.png" alt="">


                    <h3>Yasmin Rodrigues</h3>
                </div>


                <!-- FIM ITEM DEPOIMENTO -->
                <!-- INÍCIO ITEM DEPOIMENTO -->
                <div class="col-3">
                    <ion-icon name="ribbon" class="depoimento-icone"></ion-icon>
                    <p>orem Ipsum is simply dummy text of the printing and typesetting industry</p>
                    <div class="classificacao">
                        <ion-icon name="star"></ion-icon>
                        <ion-icon name="star"></ion-icon>
                        <ion-icon name="star"></ion-icon>
                        <ion-icon name="star"></ion-icon>
                        <ion-icon name="star"></ion-icon>
                    </div>
                    <img src="assets/img/cliente-2.png" alt="">


                    <h3>Yasmin Rodrigues</h3>
                </div>


                <!-- FIM ITEM DEPOIMENTO -->
                <!-- INÍCIO ITEM DEPOIMENTO -->
                <div class="col-3">
                    <ion-icon name="ribbon" class="depoimento-icone"></ion-icon>
                    <p>orem Ipsum is simply dummy text of the printing and typesetting industry</p>
                    <div class="classificacao">
                        <ion-icon name="star"></ion-icon>
                        <ion-icon name="star"></ion-icon>
                        <ion-icon name="star"></ion-icon>
                        <ion-icon name="star"></ion-icon>
                        <ion-icon name="star"></ion-icon>
                    </div>
                    <img src="assets/img/cliente-3.png" alt="">


                    <h3>Yasmin Rodrigues</h3>
                </div>


                <!-- FIM ITEM DEPOIMENTO -->
            </div>

        </div>

    </div>
    <!-- FIM DEPOIMENTOS-->
    <h2 class= "titulo">Patricionadores</h2>
    <!-- INÍCIO MARCAS-->
    <div class="marcas">

        <div class="corpo-categorias">
            <div class="linha">

                <div class="col-5">
                <a href="https://www.nike.com.br/?utm_source=google&utm_medium=cpc&gad_source=1&gclid=Cj0KCQjw4MSzBhC8ARIsAPFOuyUyIJrxXpnz7V6yAnvww-1jBKPg8Wh2VV2NJvSy2mMcpUTNFUOzVvcaAovgEALw_wcB&utm_referrer=https://www.google.com/">
                    <img src="assets/img/Logo_nike_principal.jpg" alt="">
                    </a>
                </div>
                <div class="col-5">
                <a href="https://www.netshoes.com.br/?gad_source=1&gclid=Cj0KCQjw4MSzBhC8ARIsAPFOuyV8PKsnWOCKT1ePa0vNyADzpij0ESKC7B8-3JVQwyrhclLMb3bsPVkaArAeEALw_wcB&gclsrc=aw.ds">
                    <img src="assets/img/netshoes-logo-0.png" alt="">
                    </a>
                </div>
                <div class="col-5">
                <a href="https://www.lojacaioteixeira.com.br/">
                    <img src="assets/img/logo caio texeria.png" alt="">
                    </a>
                </div>
                <div class="col-5">
                    <a href="https://hasagstore.com.br/">
                    <img src="assets/img/hasag logo.webp" alt="">
                    </a>
                </div>

            </div>
        </div>

    </div>
    <!-- FIM MARCAS-->
  


    <!-- INÍCIO RODAPÉ-->
    <footer class="rodape">
        <div class="container">
            <div class="linha">

                <div class="rodape-col-1">
                    <h3>Baixe o nosso App</h3>
                    <p>Baixe nosso aplicativo nas melhores plataformas.</p>
                    <div class="app-logo">
                        <img src="assets/img/google.png" alt="">
                        <img src="assets/img/apple.png" alt="">
                    </div>
                </div>

                <div class="rodape-col-2">
                    <img src="assets/img/logo-2.png" alt="">
                    <p>orem Ipsum is simply dummy text of the </p>
                </div>

                <div class="rodape-col-3">
                    <h3>Mais Informações</h3>
                    <ul>
                        <li>Cupons </li>
                        <li>Blog </li>
                        <li>Política de Privacidade</li>
                        <li>Contatos</li>
                    </ul>
                </div>


                <div class="rodape-col-4">
                    <h3>Redes Sociais</h3>
                    <ul>
                        <li>Facebook </li>
                        <li>Instagram </li>
                        <li>Youtube</li>
                        <li>Twiter</li>
                    </ul>
                </div>

            </div>
            <hr>
            <p class="direitos">
                &#169; Todos os Direitos Reservados. DTEC 2024.
            </p>

        </div>

    </footer>
    <!-- FIM RODAPÉ-->

    

    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script src="assets/js/app.js"> </script>
</body>

</html>