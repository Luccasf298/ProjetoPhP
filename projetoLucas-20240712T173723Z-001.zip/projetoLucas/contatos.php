<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Título da sua página</title>
    <link rel="stylesheet" href="assets/css/style2.css">
</head>
<body>

<nav class="navbar">
    <div class="logo">
        <img src="assets/img/3-removebg-preview.png" alt="" width="300px">
    </div>

    <ul id="MenuItens">
        <li><a href="index.php">Home</a></li>
        <li><a href="produtos.php">Produtos</a></li>
        <li><a href="acessorios.php">Acessorios</a></li>
        <li><a href="contatos.php">Contatos</a></li>
        <li><a href="minha-conta.php">Minha Conta</a></li>
        <li>
            <a href="carrinho.php">
                <img src="assets/img/carrinho.png" alt="" width="120px" height="120px">
            </a>
        </li>
    </ul>
</nav>

<header>
    <h1>Entre em Contato </h1>
</header>

<main>
    <div class="container">
        <div class="info">
            <h2>Nossos Contatos</h2>
            <p><strong>Endereço:</strong>, 1400 - Cidade ademar, Estado SP</p>
            <p><strong>Telefone:</strong> (11) 96635224</p>
            <p><strong>E-mail:</strong> SurporteMOBShoes@gmail.com</p>
        </div>
          
        <div class="form">
            <h2>Envie sua  Mensagem</h2>
            <?php if (isset($_GET['enviado']) && $_GET['enviado'] == 'true'): ?>
                <p class="success">Mensagem enviada com sucesso!</p>
            <?php endif; ?>
            <form action="enviar.php" method="POST">
                <input type="text" name="nome" placeholder="Seu Nome" required>
                <input type="email" name="email" placeholder="Seu E-mail" required>
                <textarea name="mensagem" placeholder="Sua Mensagem" required></textarea>
                <button type="submit">Enviar</button>
            </form>
        </div>
    </div>
</main>

<footer>
    <p>&copy; 2024 DESPERTAR TECH . Todos os direitos reservados.</p>
</footer>

</body>
</html>
